const sdata = [
    {
        image01 :"https://wallpapercave.com/uwp/uwp2772373.jpeg",
        cardtitle:"Game Of Thrones",
        slink:"https://www.hotstar.com/in/tv/game-of-thrones/8184",
        name : "A Hotstar Orignal Series "
    },
    {
        image01:"https://www.indiewire.com/wp-content/uploads/2019/02/10_IntotheBadlands.jpg",
                cardtitle:"Into The Bad-lands",
                slink:"https://www.primevideo.com/detail/Into-the-Badlands/0R1ATPINVQKZMCAYTQCA8LG45D",
                name : "Amazon Prime Web Series "
    },
    {
        image01:"https://assets-prd.ignimgs.com/2021/08/16/the-witcher-blood-origin-cast-1629121115970.jpeg",
        cardtitle:"The Witcher",
        slink:"https://www.netflix.com/in/title/81279312?source=35",
        name : "A Netflix Orignal Web Series "
},
    {
        image01:"https://assets-prd.ignimgs.com/2021/09/15/moneyheist-1631728690722.png",
        cardtitle:"Money Heist",
        slink:"https://www.netflix.com/in/title/80192098",
        name : "A Netflix Orignal Web Series "
},
    {
        image01:"https://www.koimoi.com/wp-content/new-galleries/2020/09/with-a-month-to-go-for-the-most-awaited-sequel-of-the-year-here-are-5-fan-theories-on-mirzapur-season-2-that-will-blow-your-mind001.jpg",
        cardtitle:"Mirzapur",
        slink:"https://www.primevideo.com/detail/Mirzapur/0PDOKMV9CRLOMO5EUKNCUJLG4Q",
        name : "Amazon Prime Web Series "
}

]
export default sdata