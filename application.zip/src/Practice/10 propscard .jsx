const Images = (props) => {
    return (
        <img src={props.image01} alt="" />
    )
} 
export default Images