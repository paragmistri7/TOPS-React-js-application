import React from 'react';
import File3 from './44 file 3 ';

const File2  = () => {
    return (
        <div>
            <File3/>
        </div>
    );
};

export default File2 ;