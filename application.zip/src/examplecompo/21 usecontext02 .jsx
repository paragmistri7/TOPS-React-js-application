import Usecontext03 from "./22 usecontext03 "

const Usecontext02 = () => {
    return (
        <>
         <Usecontext03/>
        </>
    )
}
export default Usecontext02