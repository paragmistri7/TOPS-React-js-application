import Propsm from "./05 propsm"

const Propscc = (w) => {
    return (
        <>
            child props Component
            <h3> {w.name}</h3>
            
          
        </>
    )
}
export default Propscc