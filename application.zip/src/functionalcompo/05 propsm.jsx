import Propscc from "./06 propscc"

const Propsm = (v) => {
    
    return (
        <>
            parent component <br />
          <Propscc name="parag"/>
            <Propscc name="gohil" />
            
            {/* {v.game} */}
        </>
    )
}
export default Propsm